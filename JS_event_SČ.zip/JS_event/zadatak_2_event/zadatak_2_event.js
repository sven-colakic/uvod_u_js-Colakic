document.getElementById("demo").onmouseover = function() {mouseOver()};

function mouseOver() {
    document.getElementById("demo").style.backgroundColor = "blue";
}
