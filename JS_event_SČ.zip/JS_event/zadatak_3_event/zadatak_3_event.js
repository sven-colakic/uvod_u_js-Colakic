document.getElementById("demo").onclick = function() {onClick()};
function onClick() {
    document.getElementById("demo").style.backgroundColor = "grey";
}