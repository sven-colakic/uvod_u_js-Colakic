function myFunciton() {
    document.getElementById("demo").innerHTML = "Vrlo mi je dosadno i hoću igrat COD:MW";

}