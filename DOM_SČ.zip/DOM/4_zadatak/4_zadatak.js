function prikazi() {
    let slika1 = document.getElementById("slika");
    slika1.style.display = "block";
}
function sakrij() {
    let slika1 = document.getElementById("slika");
    slika1.style.display = "none";
}