let boja = ["blue","black"];
let p1 = document.getElementById("p1");
br = 0;
function prom_boja(){
    p1.style.backgroundColor = boja[br];
    br = (br + 1) % boja.length
}
