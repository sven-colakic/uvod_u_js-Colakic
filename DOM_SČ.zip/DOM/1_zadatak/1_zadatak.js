let element1 = document.getElementById("p1");
let element2 = document.getElementById("p2");
element1.innerText = element2.innerText;