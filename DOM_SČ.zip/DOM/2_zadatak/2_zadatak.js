let slika = document.getElementById("slika");
function prom_slik() {
    slika.src = "moskva.jpg"
}
